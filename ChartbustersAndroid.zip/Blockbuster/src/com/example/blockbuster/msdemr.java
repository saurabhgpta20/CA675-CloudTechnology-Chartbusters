package com.example.blockbuster;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
 
public class msdemr {
 // private static String driverName = "com.amazon.hive.jdbc3.HS2Driver";
 
  public void bridgeConnection() throws SQLException {
	  String driverName = "com.amazon.hive.jdbc3.HS2Driver";
    try {
      Class.forName(driverName);
    } catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      System.exit(1);
    }
    Connection con = DriverManager.getConnection("jdbc:hive2://54.171.101.25:10000/default", "", "");
    Statement stmt = con.createStatement();
    String tableName = "msd";
    // show tables
    String sql = "show tables '" + tableName + "'";
    System.out.println("Running: " + sql);
   ResultSet res = stmt.executeQuery(sql);
    if (res.next()) {
      System.out.println(res.getString(1));
    }

  }
}
