package com.example.blockbuster;

public class Items {
	private String colName;
	private String dataType;
	
	public Items(){}
	
	public Items(String a, String b){
		this.colName = a;
		this.dataType = b;
	}
	
	
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
}
