/** Automatically generated file. DO NOT MODIFY */
package com.example.blockbuster;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}